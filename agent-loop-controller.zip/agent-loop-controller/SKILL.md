---
name: agent-loop-controller
description: >-
  当用户想把一次性回答、项目计划、代码任务、科研流程、产品任务或写作任务变成
  可循环执行的 Agent 工作流时使用。本技能将需求转成任务契约、规划、可选
  subagent 委派、join gate、独立验收、accept/revise/block 决策，并通过
  loop_state 文件持久化状态。触发词包括 loop engineering、agent loop、门控执行、
  subagent、evaluator、verifier、gate、验收标准、迭代执行、状态化 workflow。
---

# Agent Loop Controller

## 目标

运行一个有边界、可审计、可打回的 Agent 循环：

```text
需求 -> 任务契约 -> 规划 -> 委派 -> 执行 -> 汇合 -> 门控验收 -> 决策 -> 状态更新
```

循环本身是通用协议，但 gate 必须理解具体领域。不要让第二个模型只说“看起来不错”；gate 必须基于证据、验收标准和明确决策工作。

## 核心规则

没有写下任务契约和验收标准前，不开始执行。

每一轮循环都要维护 `loop_state/` 下的状态文件。聊天上下文只是工作记忆，`loop_state/` 才是事实来源。

如果任务足够小，一次执行就能完成，不要强行套循环。直接说明协调成本高于收益，然后正常执行。

## 可引用的配套 Skill

当以下 skill 可用且确实会改变决策时引用：

- `$subagent-plan-decomposer`：已有计划后，如果任务受益于子 agent、并行、上下文隔离、reviewer/evaluator agent 或 join gate，就用它拆分执行方案。
- `$ai-opposes-ai`：用于计划、汇合结果、高风险结论、流程改动、revise/block 决策的独立反对式验收。
- `$research-target-reframing`：用于 ML/AI 研究想法、论文或方法评估，重点判断复杂性是必要复杂性还是偶然复杂性。
- `$ai-research-orchestrator`：用于面向论文的 AI/ML 研究流程，包括文献、信号、问题、claim、前人工作、实验和 reviewer risk。

不要为了显得流程复杂而调用配套 skill。只有当它的输出会影响计划、验收、打回或接受决策时才调用。

## 状态文件

按需创建或更新这些文件：

```text
loop_state/
  task_contract.md
  current_state.md
  plan.md
  delegation.md
  subagent_outputs/
  join_report.md
  gate_report.md
  decision_log.md
  artifacts/
```

首次创建状态文件或结构不清楚时，读取 `references/loop-state-templates.md`。

## 循环阶段

### 1. 需求进入

创建 `loop_state/task_contract.md`。

记录：

- 用户原始请求。
- 真实目标。
- 范围与非目标。
- 验收标准。
- 接受结果所需证据。
- 风险等级：low / medium / high。
- 预算边界：token、时间、轮数、外部副作用。
- 必需的领域 gate。
- 需要人类确认的位置。

如果缺失信息会阻塞任务契约，最多问两个澄清问题。如果不阻塞，就做一个小而明确的假设，并写入状态文件。

### 2. 规划

创建 `loop_state/plan.md`。

计划必须包含：

- 主步骤。
- 每一步的预期产物。
- 每一步的 gate 标准。
- 停止条件。
- 明确不做什么。
- 哪些部分是 `MAIN_AGENT_ONLY`。

除非用户明确要求，不要加入大范围重构、额外功能或猜测性优化。

### 3. 委派

只要满足以下任一条件，就使用 `$subagent-plan-decomposer`：

- 存在多个相互独立、上下文很重的阅读任务。
- 需要并行收集证据。
- 需要 reviewer/evaluator 独立性。
- 存在重复批处理任务。
- 多条候选路径不应该互相污染上下文。

将结果保存到 `loop_state/delegation.md`。

如果使用 subagent，每个 subagent brief 必须包含：

- 目标。
- 输入范围。
- 不允许做什么。
- 输出格式。
- 验收标准。
- 依赖或 join gate。
- 压缩级别。

主 agent 保留最终决策权、冲突处理权和面向用户的输出权。

### 4. 执行

只执行已批准的计划或已委派的工作包。

每个工作包的证据和产物保存到：

```text
loop_state/subagent_outputs/<agent_or_task_id>.md
loop_state/artifacts/
```

subagent 或任务产物必须区分：

- 事实。
- 证据。
- 假设。
- 决策。
- 未解决问题。
- 置信度。

### 5. 汇合

创建 `loop_state/join_report.md`。

汇合报告必须：

- 列出已完成的工作包。
- 将产物与任务契约逐项对照。
- 合并证据，而不是简单拼接文本。
- 识别冲突。
- 如果少数反对意见会影响风险判断，必须保留。
- 标记缺失证据。

如果必需产物缺失，不进入 gate；除非计划明确允许部分验收。

### 6. 门控验收

创建 `loop_state/gate_report.md`。

当结果涉及风险、不确定性、claim、工作流变更、面向用户的结论，或可能存在过度迎合时，使用 `$ai-opposes-ai` 做独立 gate。

Gate 结论：

```text
accept  = 验收标准满足，没有阻塞性未解决问题。
revise  = 部分满足；必须指出失败项和返工工作包。
block   = 高风险、不可验证、不安全、范围漂移，或需要人类决策。
```

Gate 检查项：

- 结果是否满足 `task_contract.md`？
- 是否符合 `plan.md`，或者偏离是否已记录？
- 每条验收标准是否都有证据？
- 是否存在把伪实现 / mock / 简化版冒充完成？
- 任务是否漂移到无关范围？
- 循环是否制造了语义债务或未解释的新概念？
- 新证据是否仍然配得上当前成本？

使用 `references/domain-gates.md` 中的领域 gate。

### 7. 决策

追加写入 `loop_state/decision_log.md`。

决策规则：

- `accept`：结束循环，汇总结论和证据。
- `revise`：只针对失败项重新进入循环。不要重跑已成功的工作。
- `block`：停止并向用户或责任人请求决策。

以下情况停止循环：

- 已接受。
- 已阻塞。
- 达到最大轮数。
- 连续两轮 revise 没有产生新证据。
- 达到预算上限。
- Gate 无法客观化到足以执行。

### 8. 更新状态

每个影响决策的里程碑之后，更新 `loop_state/current_state.md`。

它必须回答：

- 当前轮次。
- 当前目标。
- 当前计划。
- 已接受项。
- 失败项。
- 开放风险。
- 下一步动作。
- 是否需要人类输入。

## 每轮汇报格式

向用户汇报时使用这个紧凑格式：

```text
当前轮次：
决策：
已接受：
需要返工：
阻塞项：
证据：
已更新状态文件：
下一步：
```

## 质量底线

- 循环必须有限。
- 显式状态文件优先于隐藏聊天记忆。
- gate 要小，而且必须真的可能失败。
- 不允许 subagent 做最终决策。
- 不奖励“动起来”，只奖励与决策相关的新证据。
- 不通过添加新范围来拯救弱产物。
- 当测试、日志、引用、diff、指标或具体产物可用时，不要用泛泛 review 代替 gate。

## v0.1 边界

本 skill 定义的是协议，不是调度器。除非当前环境提供对应工具且用户要求执行，否则它不会自动创建 subagent、运行后台任务、创建 worktree 或收集 token 成本指标。
