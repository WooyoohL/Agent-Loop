# Loop State 模板

初始化 `loop_state/` 时使用这些模板。

## `task_contract.md`

```markdown
# 任务契约

## 用户原始请求


## 真实目标


## 范围


## 非目标


## 验收标准

| ID | 标准 | 必需证据 | Gate 类型 |
|---|---|---|---|
| AC1 |  |  |  |

## 风险等级

low / medium / high

## 预算

- 最大轮数：
- 时间上限：
- Token/成本上限：
- 是否允许外部副作用：

## 需要人类确认的位置


## 假设


## 领域 Gate

code / research / writing / product / generic
```

## `current_state.md`

```markdown
# 当前循环状态

- 当前轮次：
- 状态：planning / delegated / executing / joined / gated / accepted / revise / blocked
- 当前目标：
- 当前计划：
- 已接受项：
- 失败项：
- 开放风险：
- 下一步：
- 是否需要人类输入：
```

## `plan.md`

```markdown
# 计划

## 目标


## 步骤

| 步骤 | 负责人 | 产物 | Gate 标准 | 停止条件 |
|---|---|---|---|---|
| 1 | MAIN_AGENT_ONLY |  |  |  |

## 不做什么


## 验证策略


## 停止条件

```

## `delegation.md`

```markdown
# 委派计划

## 摘要

- 主 agent 保留：
- 是否需要 subagent：
- 并行组：
- Join gate：

## 工作包

| ID | Agent | 目标 | 输入 | 输出 | Gate | 依赖 |
|---|---|---|---|---|---|---|

## 汇合协议

```

## `join_report.md`

```markdown
# 汇合报告

## 已完成工作包


## 已合并证据


## 冲突


## 缺失证据


## 是否可以进入 Gate？

yes / no
```

## `gate_report.md`

```markdown
# Gate 报告

## 结论

accept / revise / block

## 标准检查

| 标准 | 是否通过 | 证据 | 失败原因 | 返工目标 |
|---|---|---|---|---|

## 风险


## 必需返工


## 阻塞项

```

## `decision_log.md`

```markdown
# 决策日志

## D001 - YYYY-MM-DD

- 轮次：
- 决策：
- 原因：
- 证据：
- 返工目标：
- 下一步：
```
