# 领域 Gate

使用最小但真实可失败的 gate。Gate 的作用不是补充建议，而是判断产物是否可以接受、是否需要打回、是否必须阻塞。

## 通用 Gate

- 产物满足每一条验收标准。
- 每条标准都有对应证据。
- 假设已显式写出。
- 相对计划的偏离已记录。
- 不存在未解决的高风险问题。

## 代码 Gate

只要可获得，就要求具体证据：

- 相关测试通过。
- Diff 范围严格对应任务。
- 没有无关重构。
- 没有把 mock、玩具实现、占位实现或简化版冒充完成。
- 除非明确说明理由，否则不能有静默 fallback 或宽泛吞异常。
- 公共 API、数据 schema、行为变化已记录。
- plan-vs-actual 偏离已记录。

## 科研 Gate

要求：

- problem、claim、method 已分离。
- 在判断 paper-worthiness 前，已检查是否撞前人工作。
- 评估的是扣除前人工作后的 residual contribution，而不是原始 idea。
- 实验包含 hypothesis、decision、minimum valid setup 和 stop condition。
- cheap proxy 没有扭曲原问题。
- smoke / sanity / formal experiment 层级没有混用。
- reviewer risk 聚焦最致命风险，而不是罗列所有想象中的反对意见。

## 写作 Gate

要求：

- 产物服务于明确的读者和发布场景。
- claim 要么有支撑，要么被明确标成不确定。
- 没有削弱核心论点的防御性填充。
- 没有未解释的新术语。
- 结构推进主论点，而不是为了完整性堆章节。
- 用户要求的机械风格检查已满足。

## 产品 / 工作流 Gate

要求：

- 问题具体且真实。
- 范围被压缩到最小闭环。
- 每一步都有可观察行为。
- 用户不需要相信隐藏的模型判断，也能验证结果。
- 不把未来路线图当成当前能力。

## Gate 失败标签

在 `gate_report.md` 中使用这些标签：

- `missing-evidence`
- `scope-drift`
- `pseudo-implementation`
- `semantic-debt`
- `low-decision-value`
- `invalid-proxy`
- `unresolved-risk`
- `needs-human-decision`
